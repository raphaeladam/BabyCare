﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class LogIn : System.Web.UI.Page
    {
        DataConnectionDataContext dc;
        protected void Page_Load(object sender, EventArgs e)
        {
            dc = Connection.GetDataContextInstance();

        }

        protected void LogIn_Click(object sender, EventArgs e)
        {
            if ((this.typeParent.Checked == false) && (this.typeBabysitter.Checked == false))  //if the user is a parent
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please choose type of user\");", true);
                return;
            }
            else if (this.typeParent.Checked == true)
            {
                Parent ans = (from p in dc.Parents
                              where (p.UserName == this.UserName.Text)
                              select p).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש
                BabyCareUser ans2 = (from p2 in dc.BabyCareUsers
                                     where (p2.Password == this.password.Text) && (p2.UserName == this.UserName.Text)
                                     select p2).FirstOrDefault();
                if ((ans2 == null) || (ans == null))

                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Wrong user name or password!\");", true);
                    return;
                }
                else
                {
                        Session["Type"] = "Parent";
                        Session["UserName"] = this.UserName.Text;
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Update Succesfull!\");", true);
                    
                }
            }
        
            else if (this.typeBabysitter.Checked == true)  //if the usser is a babysitter
            {

                BabySitter ans = (from b in dc.BabySitters
                                  where (b.UserName == this.UserName.Text)
                                  select b).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש
                BabyCareUser ans2 = (from b2 in dc.BabyCareUsers
                                     where (b2.Password == this.password.Text) && (b2.UserName == this.UserName.Text)
                                     select b2).FirstOrDefault();
                if ((ans2 == null) || (ans == null))

                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Wrong user name or password!\");", true);
                    return;
                }
                else

                {
                    Session["Type"] = "BabySitter";
                    Session["UserName"] = this.UserName.Text;
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Update Succesfull!\");", true);
                }
            }
            Response.Redirect("~/LandingPage.aspx");

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class EditBabysitter : System.Web.UI.Page
    {
        DataConnectionDataContext dc;

        protected void Page_Load(object sender, EventArgs e)
        {
            dc = Connection.GetDataContextInstance();

        }

        protected void editBabySitter__Click(object sender, EventArgs e)
        {
            BabySitter ans = (from p in dc.BabySitters
                              where p.UserName == ID_cb.Text
                              select p).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש
            
            BabyCareUser ans2 = (from p2 in dc.BabyCareUsers
                                 where p2.UserName == ID_cb.Text
                         select p2).FirstOrDefault();
            try
            {
                ans2.Password = password_txt.Text;
                ans.FirstName = fName.Text;
                ans.LastName = lastName.Text;
                ans.StreetName = streetName.Text;
                ans.StreetNumber = int.Parse(streetNumber.Text);
                ans.City = cities.Text;
                ans.Email = Email.Text;
                ans.PhoneNumber = phone.Text;
                ans.BirthDate = DateTime.Parse(birthDate.Text);
                dc.SubmitChanges();
                ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Update Succesfull!\");", true);
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);
            }
        }

        protected void ID_cb_SelectedIndexChanged(object sender, EventArgs e)
        {
            var ans = (from p in dc.BabySitters
                       where p.UserName == ID_cb.Text
                       select p).FirstOrDefault();
            var ans2 = (from p2 in dc.BabyCareUsers
                        where p2.UserName == ID_cb.Text
                        select p2).FirstOrDefault();
            if (ans != null)
            {
                password_txt.Text = ans2.Password;
                fName.Text = ans.FirstName;
                lastName.Text = ans.LastName;
                streetName.Text = ans.StreetName;
                streetNumber.Text = (ans.StreetNumber).ToString();
                cities.Text = ans.City;
                Email.Text = ans.Email;
                phone.Text = ans.PhoneNumber;
                birthDate.Text = ans.BirthDate.Value.Date.ToString("MM/dd/yyyy");

            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class LandingPage : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {
                this.HiUser.Text = "Hi, " + (string)Session["UserName"];
                this.HiUser.Visible = true;
                this.isLogged.Visible = false;
                this.signUp.Visible = false;

                
            }
            else
            {
                this.HiUser.Visible = false;
                this.isLogged.Visible = true;
                this.logOut_btn.Visible = false;
            }
            if ((string)Session["Type"] == "BabySitter")
            {
                this.myInvitation.Visible = true;
                this.addAvailability.Visible = true;

            }
            else
            {
            //    this.myInvitation.Visible = false;
                this.addAvailability.Visible = false;
            }

        }





        protected void LinkButton_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            Response.Redirect(Request.RawUrl);


            //  Response.Redirect("~/LogIn.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class UserRegister : System.Web.UI.Page
    {
        DataConnectionDataContext dc;
        protected void Page_Load(object sender, EventArgs e)
        {
            dc = Connection.GetDataContextInstance();
        }

        protected void addParent_Click(object sender, EventArgs e)
        {

            if (this.typeParent.Checked == true)  //if the user is a parent
            {
                Session["Type"] = "Parent";
               
                BabyCareUser ans = (from b in dc.BabyCareUsers
                                    where (b.UserName == this.userName.Text)
                                    select b).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש

                if (ans != null)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"User Allready Exist!\");", true);
                    return;
                }
                Parent bs1 = new Parent();
                BabyCareUser u1 = new BabyCareUser();
                try
                {
                    u1.UserName = userName.Text;
                    u1.Password = password.Text;
                    bs1.UserName = userName.Text;
                    bs1.FirstName = fName.Text;
                    bs1.LastName = lastName.Text;
                    bs1.StreetName = streetName.Text;
                    bs1.StreetNumber = int.Parse(streetNumber.Text);
                    bs1.City = cities.Text;
                    bs1.Email = Email.Text;
                    bs1.PhoneNumber = phone.Text;
                    bs1.BirthDate = DateTime.Parse(birthDate.Text);
                    dc.Parents.InsertOnSubmit(bs1);
                    dc.BabyCareUsers.InsertOnSubmit(u1);
                    Session["UserName"] = this.userName.Text;
                    dc.SubmitChanges();
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Updated Succesfull!\");", true);
                }
                catch
                {
                    if (userName.Text == "" || password.Text == "" || fName.Text == "" || lastName.Text == "" || streetName.Text == "" || streetNumber.Text == "" || cities.Text == "" || Email.Text == "" || phone.Text == "" || birthDate.Text == "")
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);
                    else
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"User Allready Exist!\");", true);
                }
            }else if (this.typeBabysitter.Checked == true) //if the user is a babysitter:

            {
                Session["Type"] = "BabySitter";
               
                BabyCareUser ans = (from b in dc.BabyCareUsers
                                    where (b.UserName == this.userName.Text)
                              select b).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש

                if (ans != null)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"User Allready Exist!\");", true);
                    return;
                }
               
                BabySitter bs1 = new BabySitter();
                BabyCareUser u1 = new BabyCareUser();
                try
                {
                    u1.UserName = userName.Text;
                    u1.Password = password.Text;
                    bs1.UserName = userName.Text;
                    bs1.FirstName = fName.Text;
                    bs1.LastName = lastName.Text;
                    bs1.StreetName = streetName.Text;
                    bs1.StreetNumber = int.Parse(streetNumber.Text);
                    bs1.City = cities.Text;
                    bs1.Email = Email.Text;
                    bs1.PhoneNumber = phone.Text;
                    bs1.BirthDate = DateTime.Parse(birthDate.Text);
                    dc.BabySitters.InsertOnSubmit(bs1);
                    dc.BabyCareUsers.InsertOnSubmit(u1);
                    dc.SubmitChanges();
                    Session["UserName"] = this.userName.Text;
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Updated Succesfull!\");", true);
                    Response.Redirect("~/LandingPage.aspx");

                }
                catch
                {
                    if (userName.Text == "" || password.Text == "" || fName.Text == "" || lastName.Text == "" || streetName.Text == "" || streetNumber.Text == "" || cities.Text == "" || Email.Text == "" || phone.Text == "" || birthDate.Text == "")
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);
                    else
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"something went wrong!\");", true);
                }
            } else
                ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Choose type of user\");", true);

            ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);

        }



    }
}
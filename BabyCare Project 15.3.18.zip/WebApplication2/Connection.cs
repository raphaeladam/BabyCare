﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication2
{
    class Connection
    {
        public static string connectionString = "Data Source=DESKTOP-BR2TB4I;Initial Catalog=BabySitter;Integrated Security=True";
        public static DataConnectionDataContext dbDataContext = new DataConnectionDataContext(connectionString);
        public static DataConnectionDataContext GetDataContextInstance()
        {
            return dbDataContext;
        } 
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class AddLine : System.Web.UI.Page
    {
        DataClasses1DataContext dc;
        protected void Page_Load(object sender, EventArgs e)
        {
            dc = Connection.GetDataContextInstance();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Line l1 = new Line();
            l1.origin = TextBox1.Text;
            l1.destination = TextBox2.Text;
            dc.Lines.InsertOnSubmit(l1);
            dc.SubmitChanges();

        }
    }
}
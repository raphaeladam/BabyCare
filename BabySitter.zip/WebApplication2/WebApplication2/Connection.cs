﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication2
{
    class Connection
    {
        public static string connectionString = "Data Source=.; Initial Catalog=AirLineWithData; User ID=sa;Password=1";
        public static DataClasses1DataContext dbDataContext = new DataClasses1DataContext(connectionString);
        public static DataClasses1DataContext GetDataContextInstance()
        {
            return dbDataContext;
        } 
    }
}

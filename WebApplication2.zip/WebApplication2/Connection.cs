﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication2
{
    class Connection
    {
        public static string connectionString = "Data Source=302-14;Initial Catalog=BabySitter;User ID=sa;Password=1";
        public static DataConnectionDataContext dbDataContext = new DataConnectionDataContext(connectionString);
        public static DataConnectionDataContext GetDataContextInstance()
        {
            return dbDataContext;
        } 
    }
}

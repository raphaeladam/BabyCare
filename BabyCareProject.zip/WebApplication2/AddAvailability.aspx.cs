﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class AddAvailability : System.Web.UI.Page
    {
        DataConnectionDataContext dc;

        protected void Page_Load(object sender, EventArgs e)
        {
            dc = Connection.GetDataContextInstance();

        }

        protected void add_Click(object sender, EventArgs e)
        {

            if ((string)Session["Type"] == "Parent")
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Please log in as a babysitter');", true);
            else if ((string)Session["UserName"] == null)
            {
                Response.Redirect("~/LogIn.aspx");
                if ((string)Session["Type"] == null)
                    Response.Redirect("~/LogIn.aspx");
            }
            else
            {
                BabySitterInvitation newBI = new BabySitterInvitation();

                try
                {
                    DateTime fromDT = DateTime.Parse(this.from.Text);
                    DateTime toDT = DateTime.Parse(this.to.Text);

                    newBI.UserName = (string)Session["UserName"];
                    newBI.ActualDate = DateTime.Now;
                    newBI.StartingTime = fromDT;
                    newBI.EndingTime = toDT;
                    newBI.price = int.Parse(this.price.Text);
                    newBI.Status = "available";

                    dc.BabySitterInvitations.InsertOnSubmit(newBI);
                    dc.SubmitChanges();
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Updated Succesfull!\");", true);
                }
                catch
                {
                    if (this.from.Text == "" || (this.to.Text == "" || this.price.Text == ""))
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);
                    else
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Invalid Input\");", true);
                }
            } 
         
        
        }
    }
        }
    

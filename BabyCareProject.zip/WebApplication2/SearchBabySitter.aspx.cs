﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// to fix!!!!!!!!!! how soes the forn acts for unknown user? log in.... known user? get fron sesion


namespace WebApplication2
{
    public partial class SearchBabySitter : System.Web.UI.Page
    {
        DataConnectionDataContext dc;
        //       ListViewItem lastItem = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {
                this.HiUser.Text = "Hi " + (string)(Session["UserName"]) + ",";
                this.HiUser.Visible = true;
            }
            dc = Connection.GetDataContextInstance();
            if (!IsPostBack)
            {
               
                this.from_textbox.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm ");
                this.to_textbox.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm");

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime fromDT = DateTime.Parse(this.from_textbox.Text);
                DateTime toDT = DateTime.Parse(this.to_textbox.Text);

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Invalid date');", true);
                return;
            }

            if (this.city_DropDownList.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Please choose a city');", true);
                return;
            }
            if (DateTime.Parse(this.from_textbox.Text) > (DateTime.Parse(this.to_textbox.Text)))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Choose valid time');", true);
                return; //add error window! and also check first if it looks like date
            }


            this.ListView1.Visible = true;
            this.payment.Visible = true;

           
        }

        protected void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
         
        }

        protected void Button2_Click(object sender, EventArgs e)
            
        {
            if ((string)Session["Type"] == "BabySitter")
                                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Only parents can invite babysitters');", true);
            else if ((string)Session["UserName"] == null)
                    Response.Redirect("~/LogIn.aspx");
            else
            { 
                int count = 0;
                foreach (ListViewItem itm in ListView1.Items)
                {
                    CheckBox cb = (CheckBox)itm.FindControl("CheckBox2");
                    if (cb.Checked)
                        count++;
                }
                    if (count == 0)
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('No babysitter has been chosen');", true);
                    else if (count > 1)
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('You can choose only one babysitter');", true);

                
            }

            foreach (ListViewItem itm in ListView1.Items)
            {
                CheckBox cb = (CheckBox)itm.FindControl("CheckBox2");
                if (cb.Checked)
                {


                    Label c = (Label)itm.FindControl("UserNameLabel");
                    try
                    {
                        DateTime fromDT = DateTime.Parse(this.from_textbox.Text);
                        DateTime toDT = DateTime.Parse(this.to_textbox.Text);


                        //creating a new invitation. we can add an approve of the castumer before doing it
                        Invitation ans = new Invitation();
                        ans.UserName = ((Label)itm.FindControl("UserNameLabel")).Text;
                        ans.price = int.Parse(((Label)itm.FindControl("priceLabel")).Text);
                        ans.Status = "waiting for babysitter's approval";
                        ans.ActualDate = DateTime.Now;
                        ans.StartingTime = fromDT;
                        ans.EndingTime = toDT;
                        ans.parentUserName = (string)Session["UserName"]; // change!!!!! get the userName from Raphael Parent table!!!!


                        //      ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Are you sure?');", true);
                        dc.Invitations.InsertOnSubmit(ans);
                        dc.SubmitChanges();


                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('The invitation has been sent to the babysitter');", true);
                    }
                    catch (Exception ex)
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert", "alert('Invalid date');", true);
                        return;
                    }



                }
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
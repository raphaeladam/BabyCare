﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class EditPersonalInfo : System.Web.UI.Page
    {
        DataConnectionDataContext dc;
        protected void Page_Load(object sender, EventArgs e)
        {
            
                dc = Connection.GetDataContextInstance();
            if (Session["userName"] != null)
            {
                this.userName.Text = (string)(Session["userName"]);
                this.HiUser.Text = "Hi " + (string)(Session["UserName"]) + ",";
                this.HiUser.Visible = true;


                if ((string)(Session["Type"]) == "Parent")
                    this.typeParent.Checked = true;
                else if ((string)(Session["Type"]) == "BabySitter")
                    this.typeBabysitter.Checked = true;
            }
        }

        protected void editParent_Click(object sender, EventArgs e)
        {
            this.HiUser.Text = "Hi " + (string)(Session["UserName"]) + ",";
            this.HiUser.Visible = true;


            if ((this.typeParent.Checked == false) && (this.typeBabysitter.Checked == false))  //if the user is a parent
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please choose type of user\");", true);
                return;
            }
            else if (this.typeParent.Checked == true)
            {
                Parent ans = (from p in dc.Parents
                              where (p.UserName == this.userName.Text)
                              select p).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש
                BabyCareUser ans2 = (from p2 in dc.BabyCareUsers
                                     where (p2.Password == this.password_txt.Text) && (p2.UserName == this.userName.Text)
                                     select p2).FirstOrDefault();
                if ((ans2 == null) || (ans == null))
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Wrong user name or password!\");", true);
                    return;
                }
                else
                {
                    try
                    {
                        ans2.Password = newPassword_txt.Text;
                      
                        ans.FirstName = fName.Text;
                        ans.LastName = lastName.Text;
                        ans.StreetName = streetName.Text;
                        ans.StreetNumber = int.Parse(streetNumber.Text);
                        ans.City = cities.Text;
                        ans.Email = Email.Text;
                        ans.PhoneNumber = phone.Text;
                        ans.BirthDate = DateTime.Parse(birthDate.Text); // - באג -  מחליף חודשים עם ימים!!
                        dc.SubmitChanges();
                        Session["Type"] = "Parent";
                        Session["UserName"] = this.userName.Text;
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Update Succesfull!\");", true);
                        return;
                    }
                    catch
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);
                        return;
                    }
                  
                }
            }
            else if (this.typeBabysitter.Checked == true)
            {
                    
                    BabySitter ans = (from b in dc.BabySitters
                                  where (b.UserName == this.userName.Text)
                                  select b).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש
                    BabyCareUser ans2 = (from b2 in dc.BabyCareUsers
                                         where (b2.Password == this.password_txt.Text) && (b2.UserName == this.userName.Text)
                                         select b2).FirstOrDefault();
                    if ((ans2 == null) || (ans == null))

                    {

                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Wrong user name or password!\");", true);
                        return;
                    }
                    else

                    {
                        try
                        {
                            ans2.Password = newPassword_txt.Text;
                            ans.FirstName = fName.Text;
                            ans.LastName = lastName.Text;
                            ans.StreetName = streetName.Text;
                            ans.StreetNumber = int.Parse(streetNumber.Text);
                            ans.City = cities.Text;
                            ans.Email = Email.Text;
                            ans.PhoneNumber = phone.Text;
                            ans.BirthDate = DateTime.Parse(birthDate.Text);
                            Session["Type"] = "BabySitter";
                            Session["UserName"] = this.userName.Text;
                            dc.SubmitChanges();

                        
                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Update Succesfull!\");", true);
                        return;
                    }
                        catch
                        {
                          ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please Fill All Areas!\");", true);
                        return;
                        }

                    }
                }

        }
        

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //var ans = (from p in dc.Parents
            //           where p.UserName == cities.Text
            //           select p).FirstOrDefault();
            //var ans2 = (from p2 in dc.BabyCareUsers
            //            where p2.UserName == cities.Text
            //            select p2).FirstOrDefault();
           
        }

        protected void SignIn_Click(object sender, EventArgs e)
        {
            if ((this.typeParent.Checked == false) && (this.typeBabysitter.Checked == false))  //if the user is a parent
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Please choose type of user\");", true);
                return;
            }
            else if (this.typeParent.Checked == true)
            {
                try
                {

                    Parent ans = (from p in dc.Parents
                                  where (p.UserName == this.userName.Text)
                                  select p).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש

                    BabyCareUser ans2 = (from p2 in dc.BabyCareUsers
                                         where (p2.Password == this.password_txt.Text) && (p2.UserName == this.userName.Text)
                                         select p2).FirstOrDefault();
                    if ((ans2 == null) || (ans == null))

                    {

                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Wrong username or password!\");", true);
                        return;
                    }
                    else

                    {
                        this.newPassword_txt.Text = ans2.Password;
                        fName.Text = ans.FirstName;
                        lastName.Text = ans.LastName;
                        streetName.Text = ans.StreetName;
                        streetNumber.Text = (ans.StreetNumber).ToString();
                        cities.Text = ans.City;
                        Email.Text = ans.Email;
                        phone.Text = ans.PhoneNumber;
                        birthDate.Text = ans.BirthDate.Value.Date.ToString("MM/dd/yyyy");
                        Session["Type"] = "Parent";
                        Session["UserName"] = this.userName.Text;

                    }
                    details.Visible = true;
                    HiUser.Visible = true;
                }
                catch
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Check your spell\");", true);
                }
            }
            else if (this.typeBabysitter.Checked == true)
            {

                try
                {

                    BabySitter ans = (from b in dc.BabySitters
                                      where (b.UserName == this.userName.Text)
                                  select b).FirstOrDefault(); // בוחר את כל הנתונים של המשתמש

                    BabyCareUser ans2 = (from b2 in dc.BabyCareUsers
                                         where (b2.Password == this.password_txt.Text) && (b2.UserName == this.userName.Text)
                                         select b2).FirstOrDefault();
                    if ((ans2 == null) || (ans == null))

                    {

                        ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Wrong username or password!\");", true);
                        return;
                    }
                    else

                    {
                        this.newPassword_txt.Text = ans2.Password;
                        fName.Text = ans.FirstName;
                        lastName.Text = ans.LastName;
                        streetName.Text = ans.StreetName;
                        streetNumber.Text = (ans.StreetNumber).ToString();
                        cities.Text = ans.City;
                        Email.Text = ans.Email;
                        phone.Text = ans.PhoneNumber;
                        birthDate.Text = ans.BirthDate.Value.Date.ToString("MM/dd/yyyy");
                        Session["Type"] = "BabySitter";
                        Session["UserName"] = this.userName.Text;

                    }
                    details.Visible = true;
                   
                }
                catch
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "theAlertName", "alert(\"Check your spell\");", true);
                }

            }
            Session["UserName"] = this.userName.Text;
        }
    }
}